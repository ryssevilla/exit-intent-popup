document.addEventListener('DOMContentLoaded', function() {
  var exitIntentPopup = document.querySelector('.popup');
  var popupCloseButton = document.querySelector('.popup-close');
  var popupDisplayed = false;

  var delayTimer;

  function showExitIntentPopup() {
      exitIntentPopup.classList.add('active');
      popupDisplayed = true;
  }

  document.addEventListener('mouseout', function(e) {
      if (e.clientY < 0 && !popupDisplayed) {
          // Mouse is leaving the viewport from the top (likely an exit intent).
          clearTimeout(delayTimer);
          delayTimer = setTimeout(showExitIntentPopup, 1000); // Adjust the delay time (in milliseconds) as needed
      }
  });

  popupCloseButton.addEventListener('click', function() {
      exitIntentPopup.classList.remove('active');
      popupDisplayed = false;

      // Set the exit-intent popup cookie to expire in 30 days
      var now = new Date();
      now.setTime(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      document.cookie = 'exit_intent_popup=shown; expires=' + now.toUTCString();
  });
});
