<?php
/*
Plugin Name: Exit Intent Popup Plugin
Description: Create an exit intent modal popup on all pages of the website with customizable content.
Version: 1.0
Author: Robin Sevilla
*/

// Add custom settings and fields for the popup content
function add_exit_intent_popup_settings() {
    add_option('popup_content', 'This is your exit intent popup content. You can customize it as needed.');
    add_option('popup_title', 'Exit Intent Modal Popup');

    // Register settings section
    add_settings_section('exit_intent_popup_section', 'Exit Intent Popup Settings', 'exit_intent_popup_section_callback', 'exit-intent-popup-settings');

    // Register settings fields
    add_settings_field('popup_title', 'Popup Title', 'popup_content_callback', 'exit-intent-popup-settings', 'exit_intent_popup_section');
    add_settings_field('popup_content', 'Popup Content', 'popup_content_callback', 'exit-intent-popup-settings', 'exit_intent_popup_section');

    // Save settings
    register_setting('exit-intent-popup-settings', 'popup_title');
    register_setting('exit-intent-popup-settings', 'popup_content');
}
add_action('admin_init', 'add_exit_intent_popup_settings');

function exit_intent_popup_section_callback() {
    echo '<p>Customize the exit-intent popup content:</p>';
}

function popup_content_callback() {
    $popup_content = get_option('popup_content');
    $popup_title = get_option('popup_title', 'Exit Intent Modal Popup');

    echo "<input type='text' id='popup_title' name='popup_title' value='$popup_title' placeholder='Popup Title'><br>";
    echo "<textarea id='popup_content' name='popup_content'>$popup_content</textarea>";
}

// Add a new settings menu
function add_exit_intent_popup_menu() {
    add_submenu_page(
        'options-general.php',
        'Exit Intent Popup Settings',
        'Exit Intent Popup',
        'manage_options',
        'exit-intent-popup-settings',
        'exit_intent_popup_settings_page'
    );
}
add_action('admin_menu', 'add_exit_intent_popup_menu');

// Settings page callback
function exit_intent_popup_settings_page() {
    ?>
    <div class="wrap">
        <h2>Exit Intent Popup Settings</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('exit-intent-popup-settings');
            do_settings_sections('exit-intent-popup-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Function to add the exit intent popup to the footer
function add_exit_intent_popup() {
    // Check if the exit-intent popup cookie exists
    if (!isset($_COOKIE['exit_intent_popup'])) {
        // Get the customized popup content and title
        $popup_content = get_option('popup_content', 'This is your exit intent popup content. You can customize it as needed.');
        $popup_title = get_option('popup_title', 'Exit Intent Modal Popup');

        // Enqueue the CSS file
        wp_enqueue_style('exit-intent-popup-css', plugins_url('/css/exit-intent-popup.css', __FILE__));
        ?>
        <div class="popup">
            <div class="popup-content">
                <div class="popup-close">
                    <svg fill="#676f84" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                        <path d="M 7 4 C 6.744125 4 6.4879687 4.0974687 6.2929688 4.2929688 L 4.2929688 6.2929688 C 3.9019687 6.6839688 3.9019687 7.3170313 4.2929688 7.7070312 L 11.585938 15 L 4.2929688 22.292969 C 3.9019687 22.683969 3.9019687 23.317031 4.2929688 23.707031 L 6.2929688 25.707031 C 6.6839688 26.098031 7.3170313 26.098031 7.7070312 25.707031 L 15 18.414062 L 22.292969 25.707031 C 22.682969 26.098031 23.317031 26.098031 23.707031 25.707031 L 25.707031 23.707031 C 26.098031 23.316031 26.098031 22.682969 25.707031 22.292969 L 18.414062 15 L 25.707031 7.7070312 C 26.098031 7.3170312 26.098031 6.6829688 25.707031 6.2929688 L 23.707031 4.2929688 C 23.316031 3.9019687 22.682969 3.9019687 22.292969 4.2929688 L 15 11.585938 L 7.7070312 4.2929688 C 7.5115312 4.0974687 7.255875 4 7 4 z"></path>
                    </svg>
                </div>
                <h2><?php echo esc_html($popup_title); ?></h2>
                <p><?php echo esc_html($popup_content); ?></p>
            </div>
        </div>
        <?php

        // Set a cookie to prevent showing the popup for the same user for 30 days
        setcookie('exit_intent_popup', 'shown', time() + 30 * 24 * 60 * 60, '/');
        
        // Enqueue the JavaScript file
        wp_enqueue_script('exit-intent-popup-js', plugins_url('/js/exit-intent-popup.js', __FILE__), array('jquery'), '1.0', true);
    }
}
add_action('wp_footer', 'add_exit_intent_popup');
